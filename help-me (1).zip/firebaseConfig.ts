import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

// Configuration from your provided snippet
const firebaseConfig = {
  apiKey: "AIzaSyDZ-FQmlixBq6TvaJStsZb5TWmz5hrpTjI",
  authDomain: "help-me-4229a.firebaseapp.com",
  databaseURL: "https://help-me-4229a-default-rtdb.firebaseio.com",
  projectId: "help-me-4229a",
  storageBucket: "help-me-4229a.firebasestorage.app",
  messagingSenderId: "808831432210",
  appId: "1:808831432210:web:e5dc52c416f81dfc5acacb",
  measurementId: "G-088Q1P6E4X"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export { app, db };